# Enterprise SDLC Copilot Demo

A small Python service used to demonstrate an SDLC workflow with GitHub Copilot:

**Create → Change → Document → Test**

## Suggested stack
- Python 3.11+
- FastAPI
- Pydantic
- Pytest

## Scope
The demo implements a simple customer lookup service. The objective is to show how Copilot can assist across the SDLC without generating a large codebase.

## Structure
- `src/app/api` - API endpoints
- `src/app/services` - business logic
- `src/app/repositories` - data access
- `src/app/models` - domain/request models
- `src/app/core` - configuration/shared concerns
- `tests` - unit/integration tests
- `docs` - requirements, architecture and runbooks
- `config` - environment/configuration
- `scripts` - developer/operational scripts
- `data/sample` - sample data
- `.github/workflows` - CI workflows
