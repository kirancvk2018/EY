
package com.nike.retail.util;

public class ProductUtil {
    public String process(String input) {
        return "ProductUtil processed: " + input;
    }
}
