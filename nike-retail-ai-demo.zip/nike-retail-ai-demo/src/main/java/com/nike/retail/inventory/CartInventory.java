
package com.nike.retail.inventory;

public class CartInventory {
    public String process(String input) {
        return "CartInventory processed: " + input;
    }
}
