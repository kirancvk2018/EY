
package com.nike.retail.checkout;

public class CheckoutCheckout {
    public String process(String input) {
        return "CheckoutCheckout processed: " + input;
    }
}
