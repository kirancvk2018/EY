
package com.nike.retail.loyalty;

public class ProductLoyalty {
    public String process(String input) {
        return "ProductLoyalty processed: " + input;
    }
}
