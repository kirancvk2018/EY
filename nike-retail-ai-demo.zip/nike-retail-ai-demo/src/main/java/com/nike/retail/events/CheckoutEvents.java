
package com.nike.retail.events;

public class CheckoutEvents {
    public String process(String input) {
        return "CheckoutEvents processed: " + input;
    }
}
