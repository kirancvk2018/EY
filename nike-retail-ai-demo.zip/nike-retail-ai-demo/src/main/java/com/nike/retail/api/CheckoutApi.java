
package com.nike.retail.api;

public class CheckoutApi {
    public String process(String input) {
        return "CheckoutApi processed: " + input;
    }
}
