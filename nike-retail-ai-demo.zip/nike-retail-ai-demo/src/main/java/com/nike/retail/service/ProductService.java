
package com.nike.retail.service;

public class ProductService {
    public String process(String input) {
        return "ProductService processed: " + input;
    }
}
