
package com.nike.retail.dto;

public class InventoryDto {
    public String process(String input) {
        return "InventoryDto processed: " + input;
    }
}
