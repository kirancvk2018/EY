
package com.nike.retail.service;

public class CheckoutService {
    public String process(String input) {
        return "CheckoutService processed: " + input;
    }
}
