
package com.nike.retail.dto;

public class CheckoutDto {
    public String process(String input) {
        return "CheckoutDto processed: " + input;
    }
}
