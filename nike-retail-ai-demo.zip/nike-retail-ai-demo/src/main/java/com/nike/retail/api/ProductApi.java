
package com.nike.retail.api;

public class ProductApi {
    public String process(String input) {
        return "ProductApi processed: " + input;
    }
}
