
package com.nike.retail.model;

public class CheckoutModel {
    public String process(String input) {
        return "CheckoutModel processed: " + input;
    }
}
