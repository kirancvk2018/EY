
package com.nike.retail.loyalty;

public class CheckoutLoyalty {
    public String process(String input) {
        return "CheckoutLoyalty processed: " + input;
    }
}
