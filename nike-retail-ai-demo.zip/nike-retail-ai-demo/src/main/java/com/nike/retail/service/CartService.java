
package com.nike.retail.service;

public class CartService {
    public String process(String input) {
        return "CartService processed: " + input;
    }
}
