
package com.nike.retail.api;

public class CartApi {
    public String process(String input) {
        return "CartApi processed: " + input;
    }
}
