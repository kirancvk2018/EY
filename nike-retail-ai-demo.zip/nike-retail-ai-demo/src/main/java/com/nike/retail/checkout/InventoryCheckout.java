
package com.nike.retail.checkout;

public class InventoryCheckout {
    public String process(String input) {
        return "InventoryCheckout processed: " + input;
    }
}
