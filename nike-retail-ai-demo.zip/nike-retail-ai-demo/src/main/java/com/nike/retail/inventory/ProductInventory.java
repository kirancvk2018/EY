
package com.nike.retail.inventory;

public class ProductInventory {
    public String process(String input) {
        return "ProductInventory processed: " + input;
    }
}
