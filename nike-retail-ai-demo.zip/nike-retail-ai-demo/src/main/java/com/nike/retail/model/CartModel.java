
package com.nike.retail.model;

public class CartModel {
    public String process(String input) {
        return "CartModel processed: " + input;
    }
}
