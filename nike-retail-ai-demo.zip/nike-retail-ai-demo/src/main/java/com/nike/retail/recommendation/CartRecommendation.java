
package com.nike.retail.recommendation;

public class CartRecommendation {
    public String process(String input) {
        return "CartRecommendation processed: " + input;
    }
}
