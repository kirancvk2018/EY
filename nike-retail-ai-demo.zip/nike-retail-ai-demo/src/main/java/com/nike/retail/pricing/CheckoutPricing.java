
package com.nike.retail.pricing;

public class CheckoutPricing {
    public String process(String input) {
        return "CheckoutPricing processed: " + input;
    }
}
