
package com.nike.retail.model;

public class ProductModel {
    public String process(String input) {
        return "ProductModel processed: " + input;
    }
}
