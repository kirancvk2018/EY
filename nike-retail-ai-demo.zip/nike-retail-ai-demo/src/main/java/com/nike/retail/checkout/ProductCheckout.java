
package com.nike.retail.checkout;

public class ProductCheckout {
    public String process(String input) {
        return "ProductCheckout processed: " + input;
    }
}
