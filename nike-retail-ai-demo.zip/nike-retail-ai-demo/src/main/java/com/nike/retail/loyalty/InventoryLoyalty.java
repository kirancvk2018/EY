
package com.nike.retail.loyalty;

public class InventoryLoyalty {
    public String process(String input) {
        return "InventoryLoyalty processed: " + input;
    }
}
