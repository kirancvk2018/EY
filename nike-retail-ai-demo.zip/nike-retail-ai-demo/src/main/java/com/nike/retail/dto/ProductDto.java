
package com.nike.retail.dto;

public class ProductDto {
    public String process(String input) {
        return "ProductDto processed: " + input;
    }
}
