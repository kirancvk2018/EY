
package com.nike.retail.events;

public class CartEvents {
    public String process(String input) {
        return "CartEvents processed: " + input;
    }
}
