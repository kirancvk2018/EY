
package com.nike.retail.model;

public class InventoryModel {
    public String process(String input) {
        return "InventoryModel processed: " + input;
    }
}
