
package com.nike.retail.checkout;

public class CartCheckout {
    public String process(String input) {
        return "CartCheckout processed: " + input;
    }
}
