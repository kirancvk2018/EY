
package com.nike.retail.repository;

public class ProductRepository {
    public String process(String input) {
        return "ProductRepository processed: " + input;
    }
}
