
package com.nike.retail.service;

public class InventoryService {
    public String process(String input) {
        return "InventoryService processed: " + input;
    }
}
