
package com.nike.retail.repository;

public class CheckoutRepository {
    public String process(String input) {
        return "CheckoutRepository processed: " + input;
    }
}
