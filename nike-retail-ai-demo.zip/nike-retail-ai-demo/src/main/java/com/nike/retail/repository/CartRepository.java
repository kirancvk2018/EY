
package com.nike.retail.repository;

public class CartRepository {
    public String process(String input) {
        return "CartRepository processed: " + input;
    }
}
