
package com.nike.retail.loyalty;

public class CartLoyalty {
    public String process(String input) {
        return "CartLoyalty processed: " + input;
    }
}
