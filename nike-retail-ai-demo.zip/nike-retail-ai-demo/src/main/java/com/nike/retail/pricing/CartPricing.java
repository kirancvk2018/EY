
package com.nike.retail.pricing;

public class CartPricing {
    public String process(String input) {
        return "CartPricing processed: " + input;
    }
}
