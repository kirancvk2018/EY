
package com.nike.retail.util;

public class CheckoutUtil {
    public String process(String input) {
        return "CheckoutUtil processed: " + input;
    }
}
