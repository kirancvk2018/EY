
package com.nike.retail.inventory;

public class CheckoutInventory {
    public String process(String input) {
        return "CheckoutInventory processed: " + input;
    }
}
