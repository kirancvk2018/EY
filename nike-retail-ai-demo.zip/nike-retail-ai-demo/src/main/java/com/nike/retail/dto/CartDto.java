
package com.nike.retail.dto;

public class CartDto {
    public String process(String input) {
        return "CartDto processed: " + input;
    }
}
