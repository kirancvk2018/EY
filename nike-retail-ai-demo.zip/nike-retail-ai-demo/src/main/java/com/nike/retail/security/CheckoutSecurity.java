
package com.nike.retail.security;

public class CheckoutSecurity {
    public String process(String input) {
        return "CheckoutSecurity processed: " + input;
    }
}
