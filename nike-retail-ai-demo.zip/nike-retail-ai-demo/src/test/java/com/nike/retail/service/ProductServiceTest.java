
package com.nike.retail.service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ProductServiceTest {

    @Test
    public void testProcess() {
        ProductService service = new ProductService();
        assertNotNull(service.process("nike"));
    }
}
