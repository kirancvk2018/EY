
package com.nike.retail.api;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class OrderApiTest {

    @Test
    public void testProcess() {
        OrderApi service = new OrderApi();
        assertNotNull(service.process("nike"));
    }
}
