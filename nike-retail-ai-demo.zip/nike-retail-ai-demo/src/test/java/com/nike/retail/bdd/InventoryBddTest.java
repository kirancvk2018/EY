
package com.nike.retail.bdd;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class InventoryBddTest {

    @Test
    public void testProcess() {
        InventoryBdd service = new InventoryBdd();
        assertNotNull(service.process("nike"));
    }
}
