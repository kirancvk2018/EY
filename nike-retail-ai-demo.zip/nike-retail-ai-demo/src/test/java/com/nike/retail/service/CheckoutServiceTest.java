
package com.nike.retail.service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CheckoutServiceTest {

    @Test
    public void testProcess() {
        CheckoutService service = new CheckoutService();
        assertNotNull(service.process("nike"));
    }
}
