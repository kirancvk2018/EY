
package com.nike.retail.api;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CustomerApiTest {

    @Test
    public void testProcess() {
        CustomerApi service = new CustomerApi();
        assertNotNull(service.process("nike"));
    }
}
