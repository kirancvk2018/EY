
package com.nike.retail.api;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CheckoutApiTest {

    @Test
    public void testProcess() {
        CheckoutApi service = new CheckoutApi();
        assertNotNull(service.process("nike"));
    }
}
