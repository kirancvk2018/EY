
package com.nike.retail.bdd;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class OrderBddTest {

    @Test
    public void testProcess() {
        OrderBdd service = new OrderBdd();
        assertNotNull(service.process("nike"));
    }
}
