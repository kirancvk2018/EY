
package com.nike.retail.bdd;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CustomerBddTest {

    @Test
    public void testProcess() {
        CustomerBdd service = new CustomerBdd();
        assertNotNull(service.process("nike"));
    }
}
