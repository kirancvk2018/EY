
package com.nike.retail.service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CustomerServiceTest {

    @Test
    public void testProcess() {
        CustomerService service = new CustomerService();
        assertNotNull(service.process("nike"));
    }
}
