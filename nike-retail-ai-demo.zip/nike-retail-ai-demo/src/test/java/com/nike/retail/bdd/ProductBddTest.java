
package com.nike.retail.bdd;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ProductBddTest {

    @Test
    public void testProcess() {
        ProductBdd service = new ProductBdd();
        assertNotNull(service.process("nike"));
    }
}
