
package com.nike.retail.service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class InventoryServiceTest {

    @Test
    public void testProcess() {
        InventoryService service = new InventoryService();
        assertNotNull(service.process("nike"));
    }
}
