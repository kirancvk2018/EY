
package com.nike.retail.api;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ProductApiTest {

    @Test
    public void testProcess() {
        ProductApi service = new ProductApi();
        assertNotNull(service.process("nike"));
    }
}
