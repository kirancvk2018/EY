
package com.nike.retail.service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class OrderServiceTest {

    @Test
    public void testProcess() {
        OrderService service = new OrderService();
        assertNotNull(service.process("nike"));
    }
}
