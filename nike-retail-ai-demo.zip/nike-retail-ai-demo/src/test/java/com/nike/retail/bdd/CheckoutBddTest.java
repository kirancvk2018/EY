
package com.nike.retail.bdd;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CheckoutBddTest {

    @Test
    public void testProcess() {
        CheckoutBdd service = new CheckoutBdd();
        assertNotNull(service.process("nike"));
    }
}
