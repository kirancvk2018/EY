
package com.nike.retail.api;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class InventoryApiTest {

    @Test
    public void testProcess() {
        InventoryApi service = new InventoryApi();
        assertNotNull(service.process("nike"));
    }
}
