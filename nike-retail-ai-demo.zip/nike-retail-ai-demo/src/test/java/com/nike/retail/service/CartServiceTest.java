
package com.nike.retail.service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CartServiceTest {

    @Test
    public void testProcess() {
        CartService service = new CartService();
        assertNotNull(service.process("nike"));
    }
}
