
package com.nike.retail.bdd;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CartBddTest {

    @Test
    public void testProcess() {
        CartBdd service = new CartBdd();
        assertNotNull(service.process("nike"));
    }
}
