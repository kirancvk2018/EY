
package com.nike.retail.api;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CartApiTest {

    @Test
    public void testProcess() {
        CartApi service = new CartApi();
        assertNotNull(service.process("nike"));
    }
}
