
# Nike Retail AI Demo Platform

Enterprise-style Java retail platform for demonstrating:
- AI-assisted PRDs
- User story refinement
- BDD workflows
- Executable test generation
- Shared PM → Dev → QA context
- Cursor enterprise workflows
- MCP/Jira/Confluence integration concepts

Project intentionally includes:
- Multiple domains
- Distributed service structure
- BDD assets
- PRDs
- Jira-style artifacts
- Unit test scaffolding
- Enterprise naming conventions
