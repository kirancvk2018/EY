
Feature: Returns workflow

  Scenario: Successful returns operation
    Given a valid Nike member exists
    When the customer initiates returns
    Then the system should process successfully
