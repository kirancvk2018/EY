
Feature: Pricing workflow

  Scenario: Successful pricing operation
    Given a valid Nike member exists
    When the customer initiates pricing
    Then the system should process successfully
