
Feature: Loyalty workflow

  Scenario: Successful loyalty operation
    Given a valid Nike member exists
    When the customer initiates loyalty
    Then the system should process successfully
