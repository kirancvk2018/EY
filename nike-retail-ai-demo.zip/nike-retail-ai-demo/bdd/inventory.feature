
Feature: Inventory workflow

  Scenario: Successful inventory operation
    Given a valid Nike member exists
    When the customer initiates inventory
    Then the system should process successfully
