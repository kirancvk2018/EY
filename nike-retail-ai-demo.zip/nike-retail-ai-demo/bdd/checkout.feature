
Feature: Checkout workflow

  Scenario: Successful checkout operation
    Given a valid Nike member exists
    When the customer initiates checkout
    Then the system should process successfully
