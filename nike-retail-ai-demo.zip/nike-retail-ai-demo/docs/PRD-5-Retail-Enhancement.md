
# PRD 5 — Nike Retail Enhancement

## Business Goal
Improve omnichannel customer experience for footwear and apparel.

## User Story
As a Nike customer,
I want real-time inventory visibility,
So that I can reserve products before checkout.

## Acceptance Criteria
- Inventory should refresh within 5 seconds
- Reservation timeout should be configurable
- Mobile checkout should support loyalty redemption

## Priority
High

## Dependencies
- Inventory Service
- Checkout Service
- Loyalty Platform
