
# Architecture Overview

Domains:
- Inventory
- Checkout
- Pricing
- Loyalty
- Fulfillment

Patterns:
- Service Layer
- Repository Layer
- Event-driven integration
- BDD-first validation
- AI-assisted delivery lifecycle
